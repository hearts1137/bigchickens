<div id="sociallogin" class="section" data-settings="<?php p(json_encode($_)) ?>">
    <div id="sociallogin_settings_app"></div>
</div>
