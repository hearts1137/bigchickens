OC.L10N.register(
    "sociallogin",
    {
    "Save" : "Ruaj",
    "None" : "Asnjë",
    "Secret" : "Sekret",
    "Title" : "Titulli",
    "Scope" : "Shtrirje"
},
"nplurals=2; plural=(n != 1);");
