OC.L10N.register(
    "sociallogin",
    {
    "Save" : "შენახვა",
    "None" : "არც ერთი",
    "Secret" : "საიდუმლო",
    "Title" : "სათაური",
    "Scope" : "ფარგლები"
},
"nplurals=2; plural=(n!=1);");
