OC.L10N.register(
    "sociallogin",
    {
    "Log in with username or email" : "ユーザー名またはメールアドレスでログインする",
    "Log in with %s" : "%sでログインする",
    "Save" : "保存",
    "None" : "なし",
    "Team ID" : "チームID",
    "Secret" : "シークレットキー",
    "Title" : "タイトル",
    "Client Secret" : "クライアントシークレットキー",
    "Scope" : "スコープ"
},
"nplurals=1; plural=0;");
