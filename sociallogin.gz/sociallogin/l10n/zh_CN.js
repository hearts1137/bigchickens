OC.L10N.register(
    "sociallogin",
    {
    "Log in with username or email" : "使用用户名或电子邮箱登录",
    "Log in with %s" : "使用%s登录",
    "Save" : "保存",
    "None" : "无",
    "Team ID" : "团队 ID",
    "Secret" : "Secret",
    "Title" : "标题",
    "Client Id" : "客户端ID",
    "Client Secret" : "客户端密钥",
    "Scope" : "适用范围",
    "Consumer key" : "网站密钥"
},
"nplurals=1; plural=0;");
