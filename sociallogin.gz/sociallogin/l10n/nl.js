OC.L10N.register(
    "sociallogin",
    {
    "Save" : "Opslaan",
    "None" : "Geen",
    "Team ID" : "Team ID",
    "Secret" : "Vertrouwelijk",
    "Title" : "Titel",
    "Client Secret" : "Client Geheim",
    "Scope" : "Scope",
    "Consumer key" : "Consumer key"
},
"nplurals=2; plural=(n != 1);");
