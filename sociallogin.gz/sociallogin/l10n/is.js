OC.L10N.register(
    "sociallogin",
    {
    "Save" : "Vista",
    "None" : "Ekkert",
    "Secret" : "Leyni",
    "Title" : "Titill",
    "Client Secret" : "Leynilykill biðlara",
    "Scope" : "Umfang",
    "Consumer key" : "Lykill notanda"
},
"nplurals=2; plural=(n % 10 != 1 || n % 100 == 11);");
