OC.L10N.register(
    "sociallogin",
    {
    "Save" : "Зачувај",
    "None" : "Ништо",
    "Secret" : "Тајна",
    "Title" : "Наслов",
    "Scope" : "Опсег"
},
"nplurals=2; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : 1;");
