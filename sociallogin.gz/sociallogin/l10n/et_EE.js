OC.L10N.register(
    "sociallogin",
    {
    "Save" : "Salvesta",
    "None" : "Pole",
    "Secret" : "Salajane",
    "Title" : "Pealkiri",
    "Scope" : "Skoop"
},
"nplurals=2; plural=(n != 1);");
