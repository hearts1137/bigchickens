OC.L10N.register(
    "sociallogin",
    {
    "Save" : "Save",
    "None" : "None",
    "Team ID" : "Team ID",
    "Secret" : "Secret",
    "Scope" : "Scope"
},
"nplurals=2; plural=(n!=1);");
