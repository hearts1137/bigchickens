OC.L10N.register(
    "sociallogin",
    {
    "Save" : "Salva",
    "None" : "Nessuno",
    "Team ID" : "ID team",
    "Secret" : "Segreta",
    "Title" : "Titolo",
    "Client Secret" : "Segreto del client",
    "Scope" : "Ambito",
    "Consumer key" : "Chiave cliente",
    "Custom Discourse" : "Discourse personalizzato"
},
"nplurals=3; plural=n == 1 ? 0 : n != 0 && n % 1000000 == 0 ? 1 : 2;");
