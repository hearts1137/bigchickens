# Changelog
All notable changes to this project will be documented in this file.

## 1.17.0

- Compatibility with Nextcloud 30

## 1.16.0

- Compatibility with Nextcloud 29
- Drop support for older Nextcloud versions 20-25

## 1.15.0

### Added

- Compatibility with Nextcloud 28

### Fixed

- Make sure to load css also on the login page

