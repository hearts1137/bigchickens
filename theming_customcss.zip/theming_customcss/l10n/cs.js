OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "Uloženo",
    "Error" : "Chyba",
    "Custom CSS" : "Uživatelsky určený CSS styl",
    "Adjust the Nextcloud theme with custom CSS" : "Upravit motiv vzhledu Nextcloud pomocí uživatelsky určeného CSS stylu",
    "You can specify your own CSS here. Be aware that this might break something after upgrade." : "Svůj vlastní CSS styl je možné zadat sem. Mějte na paměti, že toto může po přechodu na novější verzi něco rozbít.",
    "Insert your custom CSS here …" : "Svůj uživatelsky určený CSS styl vložte sem…",
    "Save" : "Uložit"
},
"nplurals=4; plural=(n == 1 && n % 1 == 0) ? 0 : (n >= 2 && n <= 4 && n % 1 == 0) ? 1: (n % 1 != 0 ) ? 2 : 3;");
