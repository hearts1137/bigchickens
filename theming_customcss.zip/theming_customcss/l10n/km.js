OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "បាន​រក្សាទុក",
    "Error" : "កំហុស",
    "Save" : "រក្សាទុក"
},
"nplurals=1; plural=0;");
