OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "Αποθηκεύτηκε",
    "Error" : "Σφάλμα",
    "Save" : "Αποθήκευση"
},
"nplurals=2; plural=(n != 1);");
