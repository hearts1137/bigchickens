OC.L10N.register(
    "theming_customcss",
    {
    "Error" : "வழு",
    "Save" : "சேமிக்க "
},
"nplurals=2; plural=(n != 1);");
