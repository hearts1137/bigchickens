OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "Uložené",
    "Error" : "Chyba",
    "Custom CSS" : "Vlastné CSS",
    "Adjust the Nextcloud theme with custom CSS" : "Vylepšiť motív vzhľadu Nextcloudu s vlastným CSS",
    "You can specify your own CSS here. Be aware that this might break something after upgrade." : "Sem môžete zadať svoj vlastný CSS. Uvedomte si, že to môže po aktualizácii niečo rozbiť.",
    "Insert your custom CSS here …" : "Sem vložte vaše vlastné CSS...",
    "Save" : "Uložiť"
},
"nplurals=4; plural=(n % 1 == 0 && n == 1 ? 0 : n % 1 == 0 && n >= 2 && n <= 4 ? 1 : n % 1 != 0 ? 2: 3);");
