OC.L10N.register(
    "theming_customcss",
    {
    "Error" : "දෝෂය",
    "Save" : "සුරකින්න"
},
"nplurals=2; plural=(n != 1);");
