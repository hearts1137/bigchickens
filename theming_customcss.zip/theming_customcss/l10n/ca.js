OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "Desat",
    "Error" : "Error",
    "Custom CSS" : "CSS personalitzat",
    "Adjust the Nextcloud theme with custom CSS" : "Ajusteu el tema Nextcloud amb CSS personalitzat",
    "You can specify your own CSS here. Be aware that this might break something after upgrade." : "Podeu especificar el vostre propi CSS aquí. Tingueu en compte que això podria trencar alguna cosa després d’una actualització.",
    "Insert your custom CSS here …" : "Insereix el teu CSS personalitzat aquí …",
    "Save" : "Desa"
},
"nplurals=2; plural=(n != 1);");
