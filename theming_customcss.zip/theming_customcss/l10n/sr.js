OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "Сачувано",
    "Error" : "Грешка",
    "Custom CSS" : "Прилагођени CSS",
    "Adjust the Nextcloud theme with custom CSS" : "Подесите Nextcloud тему прилагођеним CSS",
    "You can specify your own CSS here. Be aware that this might break something after upgrade." : "Овде можете да наведете свој CSS. Водите рачуна да ово може покварити нешто након ажурирања.",
    "Insert your custom CSS here …" : "Уметните овде свој прилагођени CSS …",
    "Save" : "Сачувај"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);");
