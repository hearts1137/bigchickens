OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "Gordeta",
    "Error" : "Errorea",
    "Custom CSS" : "CSS pertsonalizatua",
    "Adjust the Nextcloud theme with custom CSS" : "Nextcloud itxura CSS pertsonalizatuarekin doitu",
    "You can specify your own CSS here. Be aware that this might break something after upgrade." : "Zure CSS zehaztu dezakezu hemen. Kontuan izan eguneratzearen ondoren zerbait hautsi dezakeela horrek.",
    "Insert your custom CSS here …" : "Sartu zure CSS pertsonalizatua hemen …",
    "Save" : "Gorde"
},
"nplurals=2; plural=(n != 1);");
