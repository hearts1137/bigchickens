OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "Disimpan",
    "Error" : "Galat",
    "Save" : "Simpan"
},
"nplurals=1; plural=0;");
