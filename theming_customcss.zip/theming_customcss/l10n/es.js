OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "Guardado",
    "Error" : "Error",
    "Custom CSS" : "CSS personalizado",
    "Adjust the Nextcloud theme with custom CSS" : "Ajuste el tema de Nextcloud con CSS personalizado",
    "You can specify your own CSS here. Be aware that this might break something after upgrade." : "Puede especificar su propio código CSS aquí. Tenga en cuenta que esto podría causar problemas con algún componente luego de una actualización.",
    "Insert your custom CSS here …" : "Inserte su CSS personalizado aquí...",
    "Save" : "Guardar"
},
"nplurals=3; plural=n == 1 ? 0 : n != 0 && n % 1000000 == 0 ? 1 : 2;");
