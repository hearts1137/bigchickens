OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "Đã lưu",
    "Error" : "Lỗi",
    "Custom CSS" : "Tùy chỉnh CSS",
    "Adjust the Nextcloud theme with custom CSS" : "Điều chỉnh chủ đề Nextcloud bằng CSS tùy chỉnh",
    "You can specify your own CSS here. Be aware that this might break something after upgrade." : "Bạn có thể chỉ định CSS của riêng mình tại đây. Xin lưu ý rằng điều này có thể làm hỏng thứ gì đó sau khi nâng cấp.",
    "Insert your custom CSS here …" : "Chèn CSS tùy chỉnh của bạn vào đây…",
    "Save" : "Lưu"
},
"nplurals=1; plural=0;");
