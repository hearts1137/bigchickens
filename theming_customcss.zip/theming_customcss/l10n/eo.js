OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "Konservita",
    "Error" : "Eraro",
    "Save" : "Konservi"
},
"nplurals=2; plural=(n != 1);");
