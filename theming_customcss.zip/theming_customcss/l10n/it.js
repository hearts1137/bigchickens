OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "Salvato",
    "Error" : "Errore",
    "Save" : "Salva"
},
"nplurals=3; plural=n == 1 ? 0 : n != 0 && n % 1000000 == 0 ? 1 : 2;");
