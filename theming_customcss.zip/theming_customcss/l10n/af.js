OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "Bewaar",
    "Error" : "Fout",
    "Save" : "Bewaar"
},
"nplurals=2; plural=(n != 1);");
