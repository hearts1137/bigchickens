OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "Saved",
    "Error" : "Error",
    "Save" : "Save"
},
"nplurals=2; plural=(n!=1);");
