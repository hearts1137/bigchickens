OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "已儲存",
    "Error" : "錯誤",
    "Custom CSS" : "自訂 CSS",
    "Adjust the Nextcloud theme with custom CSS" : "使用自訂 CSS 調整 Nextcloud 佈景主題",
    "You can specify your own CSS here. Be aware that this might break something after upgrade." : "您可以在此指定您自己的 CSS。請注意，這可能會在升級後弄壞一些東西。",
    "Insert your custom CSS here …" : "在此插入您的自訂 CSS……",
    "Save" : "儲存"
},
"nplurals=1; plural=0;");
