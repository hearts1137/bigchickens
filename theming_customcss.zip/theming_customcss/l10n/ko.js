OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "저장됨",
    "Error" : "오류",
    "Adjust the Nextcloud theme with custom CSS" : "사용자 정의 CSS를 통해 이 Nextcloud의 테마를 수정하기",
    "Save" : "저장"
},
"nplurals=1; plural=0;");
