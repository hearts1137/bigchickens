OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "Enregistrat",
    "Error" : "Error",
    "Save" : "Enregistrar"
},
"nplurals=2; plural=(n > 1);");
