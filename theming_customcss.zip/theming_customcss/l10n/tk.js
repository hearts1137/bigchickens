OC.L10N.register(
    "theming_customcss",
    {
    "Error" : "ýalňyşlyk",
    "Save" : "Saklamak"
},
"nplurals=2; plural=(n != 1);");
