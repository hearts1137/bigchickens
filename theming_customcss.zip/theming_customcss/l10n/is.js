OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "Vistað",
    "Error" : "Villa",
    "Custom CSS" : "Sérsniðið CSS",
    "Adjust the Nextcloud theme with custom CSS" : "Laga Nextcloud-þema með sérsniðnu CSS",
    "You can specify your own CSS here. Be aware that this might break something after upgrade." : "Þú getur tilgreint þitt eigið CSS hér. Athugaðu að það getur skemmt eitthvað eftir uppfærslu.",
    "Insert your custom CSS here …" : "Settu hér inn sérsniðið CSS …",
    "Save" : "Vista"
},
"nplurals=2; plural=(n % 10 != 1 || n % 100 == 11);");
