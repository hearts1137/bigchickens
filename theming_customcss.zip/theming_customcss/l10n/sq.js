OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "Ruajtur",
    "Error" : "Gabim",
    "Save" : "Ruaj"
},
"nplurals=2; plural=(n != 1);");
