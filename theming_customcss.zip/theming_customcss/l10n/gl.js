OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "Gardado",
    "Error" : "Erro",
    "Custom CSS" : "CSS personalizado",
    "Adjust the Nextcloud theme with custom CSS" : "Axustar o tema de Nextcloud cun CSS personalizado",
    "You can specify your own CSS here. Be aware that this might break something after upgrade." : "Pode especificar aquí o seu propio CSS. Teña en conta que isto pode rachar algo após a actualización.",
    "Insert your custom CSS here …" : "Insira aquí o seu CSS personalizado…",
    "Save" : "Gardar"
},
"nplurals=2; plural=(n != 1);");
