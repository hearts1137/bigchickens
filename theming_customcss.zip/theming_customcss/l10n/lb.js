OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "Gespäichert",
    "Error" : "Fehler",
    "Save" : "Späicheren"
},
"nplurals=2; plural=(n != 1);");
