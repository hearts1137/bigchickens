OC.L10N.register(
    "theming_customcss",
    {
    "Error" : "شسیب",
    "Save" : "ساتل"
},
"nplurals=2; plural=(n != 1);");
