OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "دخیره شد",
    "Error" : "خطا",
    "Custom CSS" : "Custom CSS",
    "Adjust the Nextcloud theme with custom CSS" : "Adjust the Nextcloud theme with custom CSS",
    "You can specify your own CSS here. Be aware that this might break something after upgrade." : "You can specify your own CSS here. Be aware that this might break something after upgrade.",
    "Insert your custom CSS here …" : "Insert your custom CSS here …",
    "Save" : "ذخیره"
},
"nplurals=2; plural=(n > 1);");
