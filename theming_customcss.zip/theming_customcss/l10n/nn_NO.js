OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "Lagra",
    "Error" : "Feil",
    "Save" : "Lagre"
},
"nplurals=2; plural=(n != 1);");
