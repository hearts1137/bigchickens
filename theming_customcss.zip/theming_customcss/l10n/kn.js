OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "﻿ಉಳಿಸಿದ",
    "Error" : "﻿ತಪ್ಪಾಗಿದೆ",
    "Save" : "﻿ಉಳಿಸಿ"
},
"nplurals=2; plural=(n > 1);");
