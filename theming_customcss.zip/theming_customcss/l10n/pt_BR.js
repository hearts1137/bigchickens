OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "Salvo",
    "Error" : "Erro",
    "Custom CSS" : "CSS customizado",
    "Adjust the Nextcloud theme with custom CSS" : "Ajuste o tema Nextcloud com CSS personalizado",
    "You can specify your own CSS here. Be aware that this might break something after upgrade." : "Você pode especificar seu próprio CSS aqui. Esteja ciente de que isso pode quebrar algo após a atualização.",
    "Insert your custom CSS here …" : "Insira seu CSS personalizado aqui…",
    "Save" : "Salvar"
},
"nplurals=3; plural=(n == 0 || n == 1) ? 0 : n != 0 && n % 1000000 == 0 ? 1 : 2;");
