OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "Gespeichert",
    "Error" : "Fehler",
    "Custom CSS" : "Benutzerdefiniertes CSS",
    "Adjust the Nextcloud theme with custom CSS" : "Passen Sie das Nextcloud-Design mit benutzerdefiniertem CSS an",
    "You can specify your own CSS here. Be aware that this might break something after upgrade." : "Hier können Sie Ihr eigenes CSS eingeben. Beachten Sie bitte, dass dies nach einem Upgrade zu Fehlern führen kann.",
    "Insert your custom CSS here …" : "Geben Sie hier ihr eigenes CSS ein …",
    "Save" : "Speichern"
},
"nplurals=2; plural=(n != 1);");
