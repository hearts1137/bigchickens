OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "Enregistré",
    "Error" : "Erreur",
    "Custom CSS" : "CSS personnalisé",
    "Adjust the Nextcloud theme with custom CSS" : "Adaptez le thème Nextcloud avec du CSS personnalisé",
    "You can specify your own CSS here. Be aware that this might break something after upgrade." : "Vous pouvez spécifier votre propre CSS ici. Soyez conscient que cela peut casser quelque chose après la mise à jour.",
    "Insert your custom CSS here …" : "Ajoutez votre CSS personnalisé ici ...",
    "Save" : "Enregistrer"
},
"nplurals=3; plural=(n == 0 || n == 1) ? 0 : n != 0 && n % 1000000 == 0 ? 1 : 2;");
