OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "บันทึกแล้ว",
    "Error" : "ข้อผิดพลาด",
    "Save" : "บันทึก"
},
"nplurals=1; plural=0;");
