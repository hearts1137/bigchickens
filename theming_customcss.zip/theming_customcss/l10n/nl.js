OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "Opgeslagen",
    "Error" : "Fout",
    "Adjust the Nextcloud theme with custom CSS" : "Pas het Nextcloud thema aan met aangepaste CSS",
    "Save" : "Opslaan"
},
"nplurals=2; plural=(n != 1);");
