OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "נשמרה",
    "Error" : "שגיאה",
    "Save" : "שמירה"
},
"nplurals=3; plural=(n == 1 && n % 1 == 0) ? 0 : (n == 2 && n % 1 == 0) ? 1: 2;");
