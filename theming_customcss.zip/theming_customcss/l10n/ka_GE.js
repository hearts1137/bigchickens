OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "შენახულია",
    "Error" : "შეცდომა",
    "Save" : "შენახვა"
},
"nplurals=2; plural=(n!=1);");
