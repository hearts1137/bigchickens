OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "Kaydedildi",
    "Error" : "Hata",
    "Custom CSS" : "Özel CSS",
    "Adjust the Nextcloud theme with custom CSS" : "Nextcloud temasını özel CSS ile ayarlayın",
    "You can specify your own CSS here. Be aware that this might break something after upgrade." : "Özel CSS kodunu buraya yazabilirsiniz. Yaptığınız değişikliklerin yükseltme işlemi sonrası bir şeyleri çalışmaz kılabileceğini unutmayın.",
    "Insert your custom CSS here …" : "Özel CSS kodunuzu buraya yazın…",
    "Save" : "Kaydet"
},
"nplurals=2; plural=(n > 1);");
