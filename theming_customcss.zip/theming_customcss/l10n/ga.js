OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "Shábháil",
    "Error" : "Earráid",
    "Custom CSS" : "CSS saincheaptha",
    "Adjust the Nextcloud theme with custom CSS" : "Coigeartaigh an téama Nextcloud le CSS saincheaptha",
    "You can specify your own CSS here. Be aware that this might break something after upgrade." : "Is féidir leat do CSS féin a shonrú anseo. Bí ar an eolas go bhféadfadh sé seo rud éigin a bhriseadh tar éis uasghrádú.",
    "Insert your custom CSS here …" : "Cuir isteach do CSS saincheaptha anseo ...",
    "Save" : "Sábháil"
},
"nplurals=5; plural=(n==1 ? 0 : n==2 ? 1 : n<7 ? 2 : n<11 ? 3 : 4);");
