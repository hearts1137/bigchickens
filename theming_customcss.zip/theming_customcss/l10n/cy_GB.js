OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "Wedi'u cadw",
    "Error" : "Gwall",
    "Save" : "Cadw"
},
"nplurals=4; plural=(n==1) ? 0 : (n==2) ? 1 : (n != 8 && n != 11) ? 2 : 3;");
