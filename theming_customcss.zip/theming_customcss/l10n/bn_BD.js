OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "সংরক্ষণ করা হলো",
    "Error" : "সমস্যা",
    "Save" : "সংরক্ষণ"
},
"nplurals=2; plural=(n != 1);");
