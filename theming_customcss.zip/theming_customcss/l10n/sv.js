OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "Sparat",
    "Error" : "Fel",
    "Save" : "Spara"
},
"nplurals=2; plural=(n != 1);");
