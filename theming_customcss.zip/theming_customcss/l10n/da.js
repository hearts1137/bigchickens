OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "Gemt",
    "Error" : "Fejl",
    "Save" : "Gem"
},
"nplurals=2; plural=(n != 1);");
