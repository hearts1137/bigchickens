OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "Хадгалах",
    "Error" : "Алдаа",
    "Save" : "Хадгалах"
},
"nplurals=2; plural=(n != 1);");
