OC.L10N.register(
    "theming_customcss",
    {
    "Error" : "ایرر",
    "Save" : "حفظ"
},
"nplurals=2; plural=(n != 1);");
