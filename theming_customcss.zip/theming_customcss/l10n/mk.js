OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "Зачувано",
    "Error" : "Грешка",
    "Save" : "Зачувај"
},
"nplurals=2; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : 1;");
