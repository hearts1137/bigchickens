OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "Guardóse",
    "Error" : "Error",
    "Custom CSS" : "CSS personalizáu",
    "Save" : "Guardar"
},
"nplurals=2; plural=(n != 1);");
