OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "Sarvadu",
    "Error" : "Errore",
    "Save" : "Sarva"
},
"nplurals=2; plural=(n != 1);");
