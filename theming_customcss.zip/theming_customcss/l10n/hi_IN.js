OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "सहेजा गया"
},
"nplurals=2; plural=(n != 1);");
