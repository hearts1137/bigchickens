OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "Goymt"
},
"nplurals=2; plural=(n != 1);");
