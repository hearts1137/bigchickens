OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "Salvestatud",
    "Error" : "Viga",
    "Custom CSS" : "Kohandatud CSS",
    "Adjust the Nextcloud theme with custom CSS" : "Muuda Nextcloudi teemat kohandatud CSS-i abil",
    "You can specify your own CSS here. Be aware that this might break something after upgrade." : "Siin saad määrata oma CSS-i reeglid. Pane tähele, et see võib pärast uuendust midagi katki teha.",
    "Insert your custom CSS here …" : "Sisesta oma kohandatud CSS siia …",
    "Save" : "Salvesta"
},
"nplurals=2; plural=(n != 1);");
