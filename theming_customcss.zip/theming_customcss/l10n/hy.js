OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "Պահված",
    "Error" : "Սխալ",
    "Custom CSS" : "Հատուկ CSS",
    "Adjust the Nextcloud theme with custom CSS" : "Հարմարեցնել Nextcloud տեսքը հատուկ CSS֊ի միջոցով",
    "You can specify your own CSS here. Be aware that this might break something after upgrade." : "Կարող եք ընտրել ձեր սեփական CSS֊ն այստեղ։ Պետք է իմանալ, որ վերազինումից հետո հնարավոր է, որ որոշ բաներ չեն աշխատի։",
    "Insert your custom CSS here …" : "Ներմուծել հատուկ CSS֊ն այստեղ ...",
    "Save" : "Պահպանել"
},
"nplurals=2; plural=(n != 1);");
