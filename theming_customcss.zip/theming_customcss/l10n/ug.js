OC.L10N.register(
    "theming_customcss",
    {
    "Error" : "خاتالىق",
    "Save" : "ساقلا"
},
"nplurals=2; plural=(n != 1);");
