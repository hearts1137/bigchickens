OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "تمّ الحفظ",
    "Error" : "خطأ",
    "Custom CSS" : "سكربتات CSS مُخصّصة",
    "Adjust the Nextcloud theme with custom CSS" : "إضبط ثيم نكست كلاود عن طريق التخصيص باستخدام CSS",
    "You can specify your own CSS here. Be aware that this might break something after upgrade." : "يُمكنك تعيين سكربتات CSS الخاصة بك هنا. إنتبه إلى أن هذا يمكن أن يكسر شيئاً ما عند الترقية.",
    "Insert your custom CSS here …" : "أدخل سكربتات CSS الخاصة بك هنا ...",
    "Save" : "حفظ"
},
"nplurals=6; plural=n==0 ? 0 : n==1 ? 1 : n==2 ? 2 : n%100>=3 && n%100<=10 ? 3 : n%100>=11 && n%100<=99 ? 4 : 5;");
