OC.L10N.register(
    "theming_customcss",
    {
    "Error" : "ຜິດພາດ",
    "Save" : "ບັນທຶກ"
},
"nplurals=1; plural=0;");
