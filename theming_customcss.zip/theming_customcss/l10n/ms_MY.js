OC.L10N.register(
    "theming_customcss",
    {
    "Error" : "Ralat",
    "Save" : "Simpan"
},
"nplurals=1; plural=0;");
