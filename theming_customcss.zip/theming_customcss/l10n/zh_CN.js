OC.L10N.register(
    "theming_customcss",
    {
    "Saved" : "已保存",
    "Error" : "错误",
    "Save" : "保存"
},
"nplurals=1; plural=0;");
