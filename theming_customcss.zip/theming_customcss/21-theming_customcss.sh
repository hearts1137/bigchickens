./occ config:app:set theming_customcss customcss --value '[class*="batch-download"] {
	display: none !important;
}'
./occ config:app:set theming_customcss cachebuster --value '1727444341838'
