OC.L10N.register(
    "sociallogin",
    {
    "Save" : "Enregistrar",
    "None" : "Cap",
    "Team ID" : "ID Team",
    "Secret" : "Secret",
    "Title" : "Títol",
    "Client Secret" : "Secret del client"
},
"nplurals=2; plural=(n > 1);");
