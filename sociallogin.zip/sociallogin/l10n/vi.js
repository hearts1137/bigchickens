OC.L10N.register(
    "sociallogin",
    {
    "Save" : "Lưu",
    "None" : "Không có",
    "Team ID" : "ID nhóm",
    "Secret" : "Mật khẩu",
    "Title" : "Tiêu đề"
},
"nplurals=1; plural=0;");
