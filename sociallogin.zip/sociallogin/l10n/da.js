OC.L10N.register(
    "sociallogin",
    {
    "Save" : "Gem",
    "None" : "Ingen",
    "Secret" : "Hemmelighed",
    "Title" : "Titel",
    "Client Secret" : "Klient-Secret",
    "Scope" : "Anvendelsesområde"
},
"nplurals=2; plural=(n != 1);");
