OC.L10N.register(
    "sociallogin",
    {
    "New user created" : "Bol vytvorený nový používateľ",
    "Save" : "Uložiť",
    "None" : "Žiadne",
    "Add default provider" : "Pridať predvoleného poskytovateľa",
    "Team ID" : "Identifikátor tímu",
    "Secret" : "Tajný kľúč",
    "Confirm remove" : "Potvrdiť odstránenie",
    "Title" : "Názov",
    "Client Secret" : "Súkromné heslo klienta",
    "Scope" : "Rozsah",
    "Scope (optional)" : "Rozsah (voliteľné)",
    "Consumer key" : "Kĺúč spotrebiteľa"
},
"nplurals=4; plural=(n % 1 == 0 && n == 1 ? 0 : n % 1 == 0 && n >= 2 && n <= 4 ? 1 : n % 1 != 0 ? 2: 3);");
