OC.L10N.register(
    "sociallogin",
    {
    "Save" : "Bewaar",
    "None" : "Geen",
    "Secret" : "Geheim",
    "Title" : "Titel",
    "Client Secret" : "Kliënt-geheim"
},
"nplurals=2; plural=(n != 1);");
