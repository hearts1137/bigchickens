OC.L10N.register(
    "sociallogin",
    {
    "Save" : "Simpan",
    "None" : "Tidak ada",
    "Secret" : "Rahasia",
    "Title" : "Judul",
    "Scope" : "Skop"
},
"nplurals=1; plural=0;");
